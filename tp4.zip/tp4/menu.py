from Biblioteca import Biblioteca
from Libro import Libro
from Cliente import Cliente

biblioteca = Biblioteca()

cliente1 = Cliente("gianca", 27, "las aucas")
cliente2 = Cliente("jesu", 19, "las virgenes")

libro1 = Libro("harry potter", "nelson", 3500)
libro2 = Libro("narnia", "marcos", 2000)

biblioteca.agregar_cliente(cliente1.obtener_cliente())
biblioteca.agregar_cliente(cliente2.obtener_cliente())

biblioteca.agregar_libro(libro1.obtener_libro())
biblioteca.agregar_libro(libro2.obtener_libro())

while True:
    print("1- Ver lista de libros, 2- Ver lista de clientes, 3- Asignar libro, 4- Libros asignados a clientes, 5- Salir ")
    opcion = int(input("Ingrese la opcion que desee: "))

    if opcion == 1:
        print("\nLISTA DE LIBROS DISPONIBLES:")
        biblioteca.mostrar_libros()
    elif opcion == 2:
        print("\nLISTA DE CLIENTES:")
        biblioteca.mostrar_clientes()

    elif opcion == 3:
        cliente_seleccionado = str(input("Ingrese el nombre cliente que desea utilizar: "))
        libro_seleccionado = str(input("Ingrese el nombre libro que desea utilizar: "))

        cliente_asignar = biblioteca.seleccionar_cliente(cliente_seleccionado)
        libro_asignar = biblioteca.seleccionar_libro(libro_seleccionado)

        biblioteca.agregar_cliente_libro(cliente_asignar, libro_asignar)

        print("\n Libro asignado al cliente:")
        biblioteca.mostrar_cliente_libro()

    elif opcion == 4:
        cliente_seleccionado = str(input("ingrese el nombre del cliente: "))
        biblioteca.cantidad_libros_clientes(cliente_seleccionado)
    elif opcion == 5:
        break
