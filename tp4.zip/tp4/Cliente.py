class Cliente:
    def __init__(self, nombre, edad, direccion):
        self.nombre = nombre
        self.edad = edad
        self.direccion = direccion
    
    def obtener_cliente(self):
        return {"nombre": self.nombre, "edad": self.edad, "direccion": self.direccion}
