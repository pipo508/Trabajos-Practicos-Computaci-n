class Libro:
    def __init__(self, titulo, autor, precio):
        self.titulo = titulo
        self.autor = autor
        self.precio = precio
    
    def obtener_libro(self):
        return {"titulo": self.titulo, "autor": self.autor, "precio": self.precio}
