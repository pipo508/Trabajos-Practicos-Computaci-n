class Biblioteca:
    def __init__(self):
        self.lista_clientes = []
        self.lista_libros = []
        self.lista_cliente_libro = []

    def mostrar_clientes(self):
        for i in self.lista_clientes:
            print(i)

    def seleccionar_cliente(self, nombre_cliente):
        for i in self.lista_clientes:
            if i['nombre'] == nombre_cliente:
                return i

    def mostrar_libros(self):
        for i in self.lista_libros:
            print(i)

    def seleccionar_libro(self, nombre_libro):
        contador = 0
        for i in self.lista_libros:
            if i['titulo'] == nombre_libro:
                return self.lista_libros.pop(contador)
            contador += 1

    def mostrar_cliente_libro(self):
        for i in self.lista_cliente_libro:
            print(i)

    def agregar_cliente(self, cliente):
        self.lista_clientes.append(cliente)

    def agregar_libro(self, libro):
        self.lista_libros.append(libro)

    def agregar_cliente_libro(self, cliente, libro):
        cliente_libro = {"cliente": cliente, "libro": libro}
        self.lista_cliente_libro.append(cliente_libro)

    def cantidad_libros_clientes(self, cliente):
        contador = 0
        for i in self.lista_cliente_libro:
            if i["cliente"]["nombre"] == cliente:
                contador += 1
        print(cliente, "tiene ", contador, "libros:")
        for i in self.lista_cliente_libro:
            if i["cliente"]["nombre"] == cliente:
                print(i["libro"])
