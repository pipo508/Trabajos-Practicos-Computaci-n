def no_cadena(str):
    if str[0:2] == "no":
        print(str)
    else:
        print("no " + str)
no_cadena("caramelo")
no_cadena("x")
no_cadena("no mal")